
SVG Drawing Animation
=========
A little experiment that explores the usage of SVG line drawing animations to precede the appearance of graphics or website elements, simulating the loading of them. 

[Article on Codrops](http://tympanus.net/codrops/?p=18012)

[Demo](http://tympanus.net/Development/SVGDrawingAnimation/)

Integrate or build upon it for free in your personal or commercial projects. Don't republish, redistribute or sell "as-is". 

Read more here: [License](http://tympanus.net/codrops/licensing/)


[© Codrops 2013](http://www.codrops.com)